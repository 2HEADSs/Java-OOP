package robotService.entities.supplements;

public class PlasticArmor extends BaseSupplement{
    private static int HARDNESS = 1;
    private static double PRICE = 10;
    public PlasticArmor() {
        super(HARDNESS, PRICE);
    }
}
