package robotService.entities.supplements;

public class MetalArmor extends BaseSupplement{
    private static int HARDNESS = 5;
    private static double PRICE = 15;
    public MetalArmor() {
        super(HARDNESS, PRICE);
    }
}
