package CarShopExtend;

public interface Sellable {
    Double getPrice();
}
