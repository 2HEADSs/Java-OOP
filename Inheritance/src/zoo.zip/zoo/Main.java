package zoo;

public class Main {
    public static void main(String[] args) {
        Bear bear = new Bear("mecho");
        System.out.println(bear.name);
    }
}
