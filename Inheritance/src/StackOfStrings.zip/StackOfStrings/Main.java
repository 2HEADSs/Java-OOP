package StackOfStrings;

public class Main {
}
